function [string] = createInventorHeader()

string = '#Inventor V2.0 ascii\r\n\r\n';